import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;

public class Board extends JFrame implements ActionListener
{
	int HEIGHT = 16;
	int WIDTH = 16;
	int BORDER = 4;
	ArrayList<Players>playersList;
	JPanel boardPanel;
	ArrayList<BoardPiece> pieces;
	ArrayList<BoardPiece> targetPieces;
	JButton exitButton;
	public Board(int humanPlayers, String difficulty)
	{
		setTitle("Ricochet Robots");
		pieces = new ArrayList<BoardPiece>();
		makePlayers(humanPlayers,difficulty);
		setBoardDesign();
		setNorthDisplay();
		setEastDisplay();
		add(boardPanel);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		this.setUndecorated(true);
		
		setVisible(true);	
	}
	
	private void makePlayers(int humanPlayers, String difficulty)
	{
		playersList = new ArrayList<Players>();
		String[] names = {"Ricky","Crypto","Octane"};
		for(int i = 1; i <= humanPlayers; i++){playersList.add(new Players(("Player "+i),"Human"));}
		if ((4 - humanPlayers) != 0){for(int i = 0; i < (4-humanPlayers); i++) {playersList.add(new Players((names[i]),"difficulty"));}}
	}
	
	private void setBoardDesign()
	{
		boardPanel = new JPanel();
		boardPanel.setLayout(new BorderLayout());
		JPanel centerPanel = new JPanel();
		JPanel piecePanel = new JPanel();
		piecePanel.setLayout(new GridLayout(HEIGHT,WIDTH));
		int x = 0; int y = 0; int count = 1;
		for(int i = 0; i < (WIDTH * HEIGHT); i++)
		{
			BoardPiece pieceButton = new BoardPiece(x,y);
			if((x == ((WIDTH/2)-1) || x == (WIDTH/2)) && (y == ((HEIGHT/2)-1) || y == (HEIGHT/2)))
			{
				pieceButton.setButtonDesign("Images/center"+count+".png");
				count+=1;
			}
			pieces.add(pieceButton);
			piecePanel.add(pieceButton);
			x += 1;
            if (x == WIDTH){ x = 0; y += 1;}
		}
		makePieceBorder();
		centerPanel.add(piecePanel);		
		boardPanel.add(centerPanel, BorderLayout.CENTER);
		
	}
	
	private void setNorthDisplay()
	{
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0,3));
		
		JLabel moves = new JLabel("Moves: ");
		moves.setFont(new Font("Helvetica",Font.PLAIN, 32));
		panel.add(moves);
		
		JLabel timeLeft = new JLabel("               Time Left: 00:00");
		timeLeft.setFont(new Font("Helvetica",Font.PLAIN, 32));
		panel.add(timeLeft);
		boardPanel.add(panel, BorderLayout.NORTH);
	}
	
	private void setEastDisplay()
	{
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(4,0));
		exitButton = new JButton("Exit Button");
		exitButton.addActionListener(this);
		mainPanel.add(exitButton);
		boardPanel.add(mainPanel,BorderLayout.EAST);
	}
	
	private void makePieceBorder()
	{
		targetPieces = new ArrayList<BoardPiece>();
		makeTopBottomSidesWall(1,0,"TopBottom");
		makeTopBottomSidesWall(11,0,"TopBottom");
		makeTopBottomSidesWall(6,15,"TopBottom");
		makeTopBottomSidesWall(11,15,"TopBottom");
		
		makeTopBottomSidesWall(0,5,"Side");
		makeTopBottomSidesWall(0,11,"Side");
		makeTopBottomSidesWall(15,3,"Side");
		makeTopBottomSidesWall(15,10,"Side");
		
		makeBorderDesign1(6,7,2,3);
		makeBorderDesign1(5,6,13,14);
		makeBorderDesign1(10,11,3,4);
		makeBorderDesign1(11,12,12,13);

		makeBorderDesign2(2,3,9,10);
		makeBorderDesign2(3,4,6,7);
		makeBorderDesign2(9,10,14,15);
		makeBorderDesign2(9,10,1,2);

		makeBorderDesign3(5,6,11,12);
		makeBorderDesign3(1,2,1,2);
		makeBorderDesign3(12,13,5,6);
		makeBorderDesign3(9,10,8,9);
		
		makeBorderDesign4(0,1,12,13);
		makeBorderDesign4(0,1,3,4);
		makeBorderDesign4(13,14,2,3);
		makeBorderDesign4(12,13,9,10);
		
		int counter = 0;
		for(int i = 0; i < targetPieces.size(); i++)
		{
			if(i<4) {targetPieces.get(i).setButtonDesign("Images/targetChipBlocks/star"+counter+".png");}
			else if(i > 3 && i < 8) {targetPieces.get(i).setButtonDesign("Images/targetChipBlocks/hex"+counter+".png");}
			else if(i > 7 && i < 12) {targetPieces.get(i).setButtonDesign("Images/targetChipBlocks/diamond"+counter+".png");}
			else{targetPieces.get(i).setButtonDesign("Images/targetChipBlocks/triangle"+counter+".png");}
			counter = (counter+1)%4;
		}

	}
	
	private void makeTopBottomSidesWall(int x1, int y1, String set)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if (set == "TopBottom")
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 & x == (x1+1)) {pieces.get(count).setBorder(1,BORDER,1,1);}
			}
			else
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == (y1+1) & x == (x1)) {pieces.get(count).setBorder(BORDER,1,1,1);}	
			}
		}	
	}
	
	private void makeBorderDesign1(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x2 && y == y1) {targetPieces.add(pieces.get(count));}
			if ((y == y1 & (x == x1 || x == x2)) || (y == y2  && x == x2))
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 & x == x2) {pieces.get(count).setBorder(1,BORDER,BORDER,1);}
				else {pieces.get(count).setBorder(BORDER,1,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign2(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x1 && y == y1) {targetPieces.add(pieces.get(count));}
			if ((y == y1 & (x == x1 || x == x2)) || (y == y2  && x == x1))
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,BORDER,BORDER);}
				else if(y == y1 && x == x2) {pieces.get(count).setBorder(1,BORDER,1,1);}
				else if(y == y2 && x == x1) {pieces.get(count).setBorder(BORDER,1,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign3(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x1 && y == y2) {targetPieces.add(pieces.get(count));}
			if ((y == y2 & (x == x1 || x == x2)) || (y == y1  && x == x1))
			{
				if(y == y2 & x == x1) {pieces.get(count).setBorder(BORDER,1,1,BORDER);}
				else if(y == y1 && x == x1) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == y2 && x == x2) {pieces.get(count).setBorder(1,BORDER,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign4(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x2 && y == y2) {targetPieces.add(pieces.get(count));}
			if ((y == y2 & (x == x1 || x == x2)) || (y == y1  && x == x2))
			{
				if(y == y2 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 && x == x2) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == y2 && x == x2) {pieces.get(count).setBorder(BORDER,BORDER,1,1);}
			}
			
		}
	}
	public void actionPerformed (ActionEvent event)
	{
		Object click = event.getSource();
        if (click instanceof JButton)
        {
        	if((JButton) click == exitButton)
        	{
        	    setVisible(false);
        	    dispose();
        	    System.exit(0);

        	}
        }
	}
	

}
