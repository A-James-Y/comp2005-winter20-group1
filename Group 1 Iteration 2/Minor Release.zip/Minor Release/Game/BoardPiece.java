import java.awt.Dimension;
import java.awt.Color;
import javax.swing.*;
import javax.swing.border.*;

public class BoardPiece extends JButton
{
	
	private int x_cord, y_cord;
    private boolean mainButton;
    private static final Color colorBackground = new Color(227,212,201);

    
    
	public BoardPiece(int x_cord,int y_cord)
	{
		
		this.x_cord = x_cord;
		this.y_cord = y_cord;
		//this.setBackground(color);
		this.setIcon((new ImageIcon("Images/piece.png")));
		this.setBorder(new LineBorder(Color.BLACK, 1));
		this.setPreferredSize(new Dimension(60, 60));
	}
	
	public void setButtonDesign(String address)
	{
		Icon image = new ImageIcon(address);
		this.setIcon(image);
	}
	
	public void setBorder(int top, int left, int bottom, int right)
	{
		Icon image = new ImageIcon("Images/targetChipBlocks/border.png");
		this.setBorder((BorderFactory.createMatteBorder(top, left, bottom, right, image)));
	}
	
	public int getXcord()
    {
        return x_cord;
    }
    
    public int getYcord()
    {
        return y_cord;
    }

}