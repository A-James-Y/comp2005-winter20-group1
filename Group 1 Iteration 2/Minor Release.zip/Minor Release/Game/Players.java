public class Players {
	
	String Name;
	String playerType;
	
	public Players(String name, String type)
	{
		this.Name = name;
		this.playerType = type;
	}
	
	public void setName(String name)
	{
		this.Name = name;
	}
	
	public String getName()
	{
		return this.Name;
	}
	
}

