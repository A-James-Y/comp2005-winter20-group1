import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.ArrayList;

public class BoardPiece extends JButton
{
	
	private int x_cord, y_cord;
    private boolean mainButton;
    private static final Color colorBackground = new Color(227,212,201);
    private String URL, playerType, targetPiece;
    private boolean stop, player, select;
    private JLabel playerLabel, targetLabel;
    private ArrayList borders;

    
    
	public BoardPiece(int x_cord,int y_cord)
	{
		this.playerType = "";
		borders = new ArrayList();
		this.targetPiece = "";
		player = false;
		select = false;
		URL = "";
		this.x_cord = x_cord;
		this.y_cord = y_cord;
		//this.setBackground(colorBackground);
		this.setIcon((new ImageIcon(URL+"Images/piece.png")));
		this.setBorder(new LineBorder(Color.BLACK, 1));
		this.setPreferredSize(new Dimension(60, 60));
	}
	
	public void setTarget(String address, String targetPiece)
	{
		targetLabel = (new JLabel(new ImageIcon(address)));
		this.setLayout(new GridLayout(0,1));
		this.add(targetLabel);
		this.targetPiece = targetPiece;
	}
	
	public void saveBorder(int top, int left, int bottom, int right)
	{
		borders.add(top);borders.add(left);borders.add(bottom);borders.add(right);
		stop = true;

	}
	
	public void setImage(String address)
	{
		JLabel tempLabel = (new JLabel(new ImageIcon(address)));
		this.setLayout(new GridLayout(0,1));
		this.add(tempLabel);
	}
	
	public void removeTarget()
	{
		this.remove(targetLabel);
		this.targetPiece = "";
	}
	
	public void setBorder(int top, int left, int bottom, int right)
	{
		Icon image = new ImageIcon(URL+"Images/targetChipBlocks/border.png");
		this.setBorder((BorderFactory.createMatteBorder(top, left, bottom, right, image)));
		saveBorder(top,left,bottom,right);
	}
	
	public ArrayList getBorders()
	{
		return borders;
	}
	
	public void removePlayer()
	{
		this.remove(playerLabel);
		this.playerType = "";
		this.player = false;
	}
	
	public void setPlayer(String address, String playerType)
	{
		playerLabel = (new JLabel(new ImageIcon(address)));
		this.add(playerLabel);
		this.playerType = playerType;
		this.player = true;
		
	}
	
	public String getPlayerType()
	{
		return this.playerType;
	}
	
	public void setPlayerType(String playerType)
	{
		this.playerType = playerType;
	}
	
	public String getTargetPiece()
	{
		return this.targetPiece;
	}
	
	public void setTargetPiece(String targetPiece)
	{
		this.targetPiece = targetPiece;
	}
	
	public void setColour()
	{
		this.setBackground(colorBackground);
	}
	
	public int getXcord()
    {
        return x_cord;
    }
    
    public int getYcord()
    {
        return y_cord;
    }
    
    public boolean getStop()
    {
    	return stop;
    }
    
    public void setStop(boolean stop)
    {
    	this.stop = stop;
    }
    
    public boolean getPlayer()
    {
    	return this.player;
    }
    
    public void setPlayer(boolean player)
    {
    	this.player = player;
    }
    
    public void setPieceSelect(boolean select)
    {
    	this.select = select;
    }
    
    public boolean getPieceSelect() //check if it can be selected
    {
    	return this.select;
    }
    
}