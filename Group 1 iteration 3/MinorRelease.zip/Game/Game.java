import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.ArrayList;

public class Game extends JFrame implements ActionListener
{
	private Board board;
	private ArrayList<Players>playersList;
	private ArrayList<JButton>playersButton;
	private ArrayList<BoardPiece> piece;
	private JPanel boardPanel, mainPanel;
	private JPanel scorePanel;
	private JTextField bidField;
	private JButton exitButton,submitButton;
	private JLabel timeLeft, moves;
	private int playerPosition, timeCounter,currentSelectButton, movesMade, minBidder;
	private String URL;
	
	public Game(int humanPlayers, String difficulty)
	{
		setupGame(humanPlayers,difficulty);
	}
	
	private void setupGame(int humanPlayers, String difficulty)
	{
		playerPosition = 0;
		URL = "";
		currentSelectButton = -1;
    	minBidder = 0;
		board = new Board();
		makePlayers(humanPlayers,difficulty);
		setTitle("Ricochet Robots");
		boardPanel = new JPanel();
		setNorthDisplay();
		setEastDisplay();
		boardPanel.add(board, BorderLayout.CENTER);
		add(boardPanel);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setUndecorated(true);
		setVisible(true);
	}
	
	private void makePlayers(int humanPlayers, String difficulty)
	{
		playersList = new ArrayList<Players>();
		String[] names = {"Ricky","Crypto","Octane"};
		for(int i = 1; i <= humanPlayers; i++){playersList.add(new Players(("Player "+i),"Human"));}
		if ((4 - humanPlayers) != 0){for(int i = 0; i < (4-humanPlayers); i++) {playersList.add(new Players((names[i]),"difficulty"));}}
		piece = board.getBoardPieces();
		setPlayers();
		
	}
	
	private void setPlayers()
	{
		int counter = 0;
		String[] colourRobots = {"orange", "blue", "green", "red"};
		for(int i = 0; i < piece.size(); i++) 
		{
			piece.get(i).addActionListener(this);
			int tempX = piece.get(i).getXcord();
			int tempY = piece.get(i).getYcord();
			if((tempX == 3 && tempY == 0) || (tempX == 3 && tempY == 4) || (tempX == 8 && tempY == 4) || (tempX == 13 && tempY ==5))//10,3 -> 1,4//0,0 -> 1,0
			{
				piece.get(i).setPlayer((URL+"Images/Robots/"+colourRobots[counter]+".png"),colourRobots[counter]);

				counter++;
			}
		}
	}
	
	private void setNorthDisplay()
	{
		movesMade = 0;
		boardPanel.setLayout(new BorderLayout());
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0,3));
		moves = new JLabel("Moves: "+movesMade);
		moves.setForeground(Color.WHITE);
		moves.setFont(new Font("Helvetica",Font.PLAIN, 32));
		panel.add(moves);
		timeCounter = 60;
		timeLeft = new JLabel("   Time Left: 01:00");
		timeLeft.setFont(new Font("Helvetica",Font.PLAIN, 32));
		timeLeft.setForeground(Color.WHITE);
		panel.add(timeLeft);
		boardPanel.setBackground(Color.BLACK);
		panel.setBackground(Color.BLACK);
		boardPanel.add(panel, BorderLayout.NORTH);
	}
	
	private void setEastDisplay()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(3,0));
		createScoreBoard();
		mainPanel.add(scorePanel);
		exitButton = new JButton("Exit Button");
		exitButton.addActionListener(this);
		mainPanel.add(exitButton);
		mainPanel.setBackground(Color.BLACK);
		boardPanel.add(mainPanel,BorderLayout.EAST);
	}
	
	private void createScoreBoard()
    {
		playersButton = new ArrayList<JButton>();
		scorePanel = new JPanel();
        scorePanel.setLayout(new GridLayout(5,0));
        for(int i = 0; i < 4; i++)
        {
            JPanel playerPanel = new JPanel();
            playerPanel.setBorder(new LineBorder(Color.BLACK, 1));
            playerPanel.setLayout(new GridLayout(0,2));
            
            JPanel splitPanel = new JPanel();
            splitPanel.setBorder(new LineBorder(Color.BLACK, 0));
            splitPanel.setLayout(new GridLayout(2,0));
            JButton playerButtonX = new JButton(playersList.get(i).getName());
            playerButtonX.addActionListener(this);
            splitPanel.add(new JButton("Score: "+playersList.get(i).getScore()));
            splitPanel.add(new JButton("Current Bid: "+playersList.get(i).getBid()));
            
            playerPanel.add(playerButtonX);
            playerPanel.add(splitPanel);
            scorePanel.add(playerPanel);
            playersButton.add(playerButtonX);
        }
        playersButton.get(playerPosition).setBackground(Color.RED);
        JPanel bidPanel = new JPanel();
        bidPanel.setBorder(new LineBorder(Color.BLACK, 1));
        bidField = new JTextField(15);
        bidField.setFont(new Font("Helvetica",Font.PLAIN, 17));
        submitButton = new JButton("Submit Bid");
        submitButton.addActionListener(this);
        bidPanel.add(bidField,BorderLayout.WEST);
        bidPanel.add(submitButton,BorderLayout.EAST);
        scorePanel.add(bidPanel);
    }
	
	public void actionPerformed (ActionEvent event)
	{
		Object click = event.getSource();
        if (click instanceof JButton)
        {
        	JButton ButtonX = (JButton) click;
        	if((JButton) click == exitButton)
        	{
        	    setVisible(false);
        	    dispose();
        	    System.exit(0);

        	}
        	else if((JButton) click == submitButton)
        	{
        		
            	int intBid = Integer.parseInt(bidField.getText());
            	playersList.get(playerPosition).setBid(intBid);
            	mainPanel.setVisible(false);
            	setEastDisplay();
            	if(timeCounter == 60) {setTime();}
            
            		
        	}
        	else if(ButtonX == playersButton.get(0) || ButtonX == playersButton.get(1) || ButtonX == playersButton.get(2) || ButtonX == playersButton.get(3))
        	{
        		playersButton.get(playerPosition).setBackground(null);
        		playerPosition = 0;
        		boolean found = false;
        		while(!found) 
        		{
        			if (ButtonX == playersButton.get(playerPosition)) {
        				playersButton.get(playerPosition).setBackground(Color.RED);
        				found = true;
        				}
        			else {playerPosition += 1;}
        		}
        	}
        	else
        	{
        		boolean notFound = true;
        		int keepCount = 0;
        		while(notFound)
        		{
        			if((piece.get(keepCount)) == ((JButton) click)) {notFound = false;}
        			else {keepCount += 1;}
        		}
        		if(((piece.get(keepCount)).getPlayer()))
            	{
            		if(!((piece.get(keepCount)).getPieceSelect())) // select color robot
            		{
            			if(currentSelectButton != -1)
            			{
            				(piece.get(currentSelectButton)).setBackground(null);
                			(piece.get(currentSelectButton)).setIcon((new ImageIcon(URL+"Images/piece.png")));
                			(piece.get(currentSelectButton)).setPieceSelect(false);
            			}
            			(piece.get(keepCount)).setIcon(null);
            			(piece.get(keepCount)).setColour();
            			(piece.get(keepCount)).setPieceSelect(true);
            			currentSelectButton = keepCount;
            		}
            		else // De-select color robot
            		{
            			(piece.get(keepCount)).setBackground(null);
            			(piece.get(keepCount)).setIcon((new ImageIcon(URL+"Images/piece.png")));
            			(piece.get(keepCount)).setPieceSelect(false);
            			currentSelectButton = -1;
            		}
            	}
        		else if(currentSelectButton != -1)
        		{
        			if(((piece.get(keepCount)).getPlayer() == false))
        			{
        				boolean move = false;
        				boolean secondMove = true;
        				boolean findY = false;
        				boolean findX = false;
        				int currentXaxis = piece.get(keepCount).getXcord();
        				int currentYaxis = piece.get(keepCount).getYcord();
        				if(currentXaxis == piece.get(currentSelectButton).getXcord()) {findY = true;}
        				else if(currentYaxis == piece.get(currentSelectButton).getYcord()){findX = true;}
        				if(findX == true || findY == true)
        				{
        					for(int keepCount1 = 0; keepCount1 < piece.size(); keepCount1++)
        					{
        						if(findY) //checks border in between Moves at y-axis
        						{
        							if((piece.get(keepCount1).getXcord() == currentXaxis) && (piece.get(keepCount1).getStop()))
        							{
        								ArrayList pieceBorder = piece.get(keepCount1).getBorders();
        								if(pieceBorder.size() > 0)
        								{
        									if(((pieceBorder.get(0)).equals(4)) || ((pieceBorder.get(2)).equals(4)))
        									{
        										int tempYcord = piece.get(keepCount1).getYcord();
        										int currentYcord = piece.get(currentSelectButton).getYcord();
        										if(((tempYcord > currentYaxis) && (tempYcord < currentYcord)) || ((tempYcord < currentYaxis) && (tempYcord > currentYcord)))
        										{
        											secondMove = false;
        										}
        									}
        								}
        							}
        						}
        						else if(findX)//checks border in between Moves at x-axis
        						{
        							if((piece.get(keepCount1).getYcord() == currentYaxis) && (piece.get(keepCount1).getStop()))
        							{
        								ArrayList pieceBorder = piece.get(keepCount1).getBorders();
        								if(pieceBorder.size() > 0)
        								{
        									if(((pieceBorder.get(1)).equals(4)) || ((pieceBorder.get(3)).equals(4)))
        									{
        										int tempXcord = piece.get(keepCount1).getXcord();
        										int currentXcord = piece.get(currentSelectButton).getXcord();
        										if(((tempXcord > currentXaxis) && (tempXcord < currentXcord)) || ((tempXcord < currentXaxis) && (tempXcord > currentXcord)))
        										{
        											secondMove = false;
        										}
        									}
        								}
        							}
        						}

        						
        						if(piece.get(keepCount).getStop() == true)//moving players to the edge
        						{	
        							ArrayList tempBorderCheck = piece.get(keepCount).getBorders();
        							if((currentYaxis == 0 && piece.get(currentSelectButton).getYcord() == 0) ||
        							  (currentYaxis == board.getBoardHeight() && piece.get(currentSelectButton).getYcord() == board.getBoardHeight())) //check at y = 0,15
        							{//move edge to edge at y axis
        								if((!(currentXaxis == 0 || currentXaxis == board.getBoardWidth())) && (tempBorderCheck.size() > 0))
        								{
        									if(currentXaxis > piece.get(currentSelectButton).getXcord()) {if(!(tempBorderCheck.get(3).equals(1))) {move = true; }}
        									else if(currentXaxis < piece.get(currentSelectButton).getXcord()) {if(!(tempBorderCheck.get(1).equals(1))) {move = true;}}
        									
        								}
        								else if(currentXaxis == 0 || currentXaxis == board.getBoardWidth()) {move = true;}
        							}

        							else if((currentXaxis == 0 && piece.get(currentSelectButton).getXcord() == 0) ||
        									(currentXaxis == board.getBoardWidth() && piece.get(currentSelectButton).getXcord() == board.getBoardWidth())) //check at x = 0,15
        							{//move edge to edge at x axis
        								if((!(currentYaxis == 0 || currentYaxis == board.getBoardHeight()))  && (tempBorderCheck.size() > 0))
        								{
           									if(currentYaxis > piece.get(currentSelectButton).getYcord()) {if(!(tempBorderCheck.get(2).equals(1))) {move = true; }}
        									else if(currentYaxis < piece.get(currentSelectButton).getYcord()) {if(!(tempBorderCheck.get(0).equals(1))) {move = true;}}
        									
        								}
        								else if(currentYaxis == 0 || currentYaxis == board.getBoardHeight()) {move = true;}
        							}

        							else if(currentXaxis == piece.get(currentSelectButton).getXcord() || currentYaxis == piece.get(currentSelectButton).getYcord()) 
        							{//move from middle to edge
        								if(piece.get(keepCount).getStop()) 
        								{
        									if(currentYaxis == 0||currentYaxis == board.getBoardHeight()||currentXaxis == 0||currentXaxis == board.getBoardWidth()){move = true;}
        									else if(findX) 
        									{
        										if(currentXaxis > piece.get(currentSelectButton).getXcord()) {if(!(tempBorderCheck.get(3).equals(1))) {move = true; }}
            									else if(currentXaxis < piece.get(currentSelectButton).getXcord()) {if(!(tempBorderCheck.get(1).equals(1))) {move = true;}}
        									}
        									else if(findY)
        									{
        										if(currentYaxis > piece.get(currentSelectButton).getYcord()) {if(!(tempBorderCheck.get(2).equals(1))) {move = true; }}
            									else if(currentYaxis < piece.get(currentSelectButton).getYcord()) {if(!(tempBorderCheck.get(0).equals(1))) {move = true;}}
        									}
        									
        								}
        								
        							}

        						}
        						if(!move)
        						{
        							if(piece.get(keepCount1).getPlayer() && (piece.get(keepCount1).getPlayerType() != piece.get(currentSelectButton).getPlayerType()))
        							{ //moving robot near robot
        								if(findX)
        								{
        									if(piece.get(keepCount1).getYcord() == currentYaxis)
        									{
        										int xCord = piece.get(currentSelectButton).getXcord();
        										if((piece.get(keepCount1).getXcord()+1 == currentXaxis) && (piece.get(keepCount1).getXcord() < xCord)){move = true;}
        										else if ((piece.get(keepCount1).getXcord()-1 == currentXaxis) && (piece.get(keepCount1).getXcord() > xCord)) {move = true;}
        									}
        								}
        								else if(findY)
        								{
        									if(piece.get(keepCount1).getXcord() == currentXaxis)
        									{
        										int yCord = piece.get(currentSelectButton).getYcord();
        										if((piece.get(keepCount1).getYcord()+1 == currentYaxis) && (piece.get(keepCount1).getYcord() < yCord)){move = true;}
        										else if ((piece.get(keepCount1).getYcord()-1 == currentYaxis) && (piece.get(keepCount1).getYcord() > yCord)) {move = true;}
        									}
        								}
        							}
        						}
        					}
        					if(move && secondMove) 
        					{
        						if((piece.get(keepCount)).getTargetPiece() == ((piece.get(currentSelectButton)).getPlayerType()))
        						{//move same color robot to targetPiece
        							piece.get(keepCount).removeTarget();
        							
        						}

        						movesMade += 1;
        						if(playersList.get(minBidder).getBid() < movesMade) 
        						{
        							moves.setText("Moves: "+"Exceeded");
        							for(int i = 0; i < piece.size(); i++) 
        							{
        								if(piece.get(i).getPlayer())
        								{
        									piece.get(i).removePlayer();
        									
        								}
        							}
        							piece.get(currentSelectButton).setBackground(null);
        							piece.get(currentSelectButton).setIcon((new ImageIcon(URL+"Images/piece.png")));
        							piece.get(currentSelectButton).setPieceSelect(false);
        							currentSelectButton = -1;
        							setPlayers();

        						}
        						
        						else
        						{
        							moves.setText("Moves: "+movesMade);
            						String currentRobPiece = piece.get(currentSelectButton).getPlayerType();
            						piece.get(currentSelectButton).removePlayer();
            						piece.get(keepCount).setPlayer((URL+"Images/Robots/"+currentRobPiece+".png"),currentRobPiece);
        						}

        						piece.get(keepCount).doClick();
								board.revalidate();
								board.repaint();
        						
        					}
        				}
        			}
        			
        		}
        	}
        
        }
	}
	
	private void setTime()
    {
        Timer times = new Timer();
        TimerTask task = new TimerTask()
        {
            public void run()
            {
            	timeCounter -= 1;
            	if (timeCounter < 10) {timeLeft.setText("   Time Left: 00:0"+timeCounter);}
            	else{timeLeft.setText("   Time Left: 00:"+timeCounter);}
                if(timeCounter == 0)
                {
                	times.cancel();
                	timeLeft.setText("       Time Over!");
                	timeCounter = 60;
                	for(int i = 0; i < playersButton.size(); i++) {
                		playersButton.get(i).setBackground(null);
                		playersButton.get(i).setEnabled(false);
                		if(playersList.get(i).getBid() < playersList.get(minBidder).getBid()){minBidder = i;}
                	}
                	playersButton.get(minBidder).setBackground(Color.GREEN);
                	submitButton.setEnabled(false);
                	bidField.setEnabled(false);
                }
            }
        };
        times.scheduleAtFixedRate(task,1000,1000);
        
    }
}
