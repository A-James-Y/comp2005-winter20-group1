public class Players {
	
	private String name, playerType;
	private int bid, score;

	public Players(String name, String type)
	{
		this.name = name;
		this.playerType = type;
		this.bid = 0;
		this.score = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	
	
	
	
	
}

