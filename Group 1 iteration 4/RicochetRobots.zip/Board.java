import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.border.*;

public class Board extends JPanel
{
	private int height;
	private int width;
	private int BORDER = 4;
	private ArrayList<BoardPiece> pieces;
	private ArrayList<BoardPiece> targetPieces, centerPieces;
	private String URL, boardType;
	private BoardPiece targetPlacement;
	public Board(String boardType)
	{
		this.boardType = boardType;
		height = 16;
		width = 16;
		URL = "";
		pieces = new ArrayList<BoardPiece>();
		setBoardDesign();
	}
	public String getBoardType()
	{
		return boardType;
	}
	public int getBoardHeight()
	{
		return height-1;
	}
	
	public int getBoardWidth()
	{
		return width-1;
	}
	
	public BoardPiece getTargetPlacement()
	{
		return centerPieces.get(0);
	}
	
	public ArrayList getTargetPieces()
	{
		return targetPieces;
	}

	
	private void setBoardDesign()
	{
		centerPieces = new ArrayList<BoardPiece>();
		JPanel centerPanel = new JPanel();
		JPanel piecePanel = new JPanel();
		piecePanel.setLayout(new GridLayout(height,width));
		int x = 0; int y = 0; int count = 1;
		for(int i = 0; i < (width * height); i++)
		{
			BoardPiece pieceButton = new BoardPiece(x,y);
			if(x == 0 || y == 0 || x == (width-1) || y == (height-1)) {pieceButton.setStop(true);}
			if((x == ((width/2)-1) || x == (width/2)) && (y == ((height/2)-1) || y == (height/2)))
			{
				pieceButton.setTarget(URL+"Images/center"+count+".png", null, null);
				centerPieces.add(pieceButton);
				count+=1;
			}
			pieces.add(pieceButton);
			piecePanel.add(pieceButton);
			x += 1;
            if (x == width){ x = 0; y += 1;}
		}
		makePieceBorder();
		makeBorderDesign4(6,7,6,7); // Make border around the targetChip placement
		makeBorderDesign3(6,7,8,9);
		makeBorderDesign1(8,9,6,7);
		makeBorderDesign2(8,9,8,9);
		for(int i = 0; i < centerPieces.size(); i++) {centerPieces.get(i).setStop(false);}
		
		centerPanel.add(piecePanel);		
		add(centerPanel);
		
	}
	
	public ArrayList getBoardPieces()
	{
		return pieces;
	}
	
	private void makePieceBorder()
	{
		targetPieces = new ArrayList<BoardPiece>();
		if(boardType.equals("Simple"))
		{
			makeTopBottomSidesWall(1,0,"TopBottom");
			makeTopBottomSidesWall(11,0,"TopBottom");
			makeTopBottomSidesWall(6,15,"TopBottom");
			makeTopBottomSidesWall(11,15,"TopBottom");
			
			makeTopBottomSidesWall(0,5,"Side");
			makeTopBottomSidesWall(0,11,"Side");
			makeTopBottomSidesWall(15,3,"Side");
			makeTopBottomSidesWall(15,10,"Side");
			
			makeBorderDesign1(6,7,2,3);
			makeBorderDesign1(5,6,13,14);
			makeBorderDesign1(10,11,3,4);
			makeBorderDesign1(11,12,12,13);

			makeBorderDesign2(2,3,9,10);
			makeBorderDesign2(3,4,6,7);
			makeBorderDesign2(9,10,14,15);
			makeBorderDesign2(9,10,1,2);

			makeBorderDesign3(5,6,11,12);
			makeBorderDesign3(1,2,1,2);
			makeBorderDesign3(12,13,5,6);
			makeBorderDesign3(9,10,8,9);
			
			makeBorderDesign4(0,1,12,13);
			makeBorderDesign4(0,1,3,4);
			makeBorderDesign4(13,14,2,3);
			makeBorderDesign4(12,13,9,10);
		}
		else
		{
			makeTopBottomSidesWall(5,0,"TopBottom");
			makeTopBottomSidesWall(8,0,"TopBottom");
			makeTopBottomSidesWall(6,15,"TopBottom");
			makeTopBottomSidesWall(10,15,"TopBottom");
			
			makeTopBottomSidesWall(0,5,"Side");
			makeTopBottomSidesWall(0,10,"Side");
			makeTopBottomSidesWall(15,2,"Side");
			makeTopBottomSidesWall(15,12,"Side");
			
			//makeBorderDesign1(6,7,2,3);	
			makeBorderDesign1(9,10,1,2);
			//makeBorderDesign1(11,12,12,13);
			
			makeBorderDesign2(4,5,6,7);
			makeBorderDesign2(4,5,8,9);
			makeBorderDesign2(9,10,10,11);
			//makeBorderDesign2(12,13,3,4);
			
			makeBorderDesign3(5,6,2,3);
			makeBorderDesign3(5,6,13,14);
			makeBorderDesign3(13,14,5,6);
			makeBorderDesign3(10,11,12,13);
			
			makeBorderDesign4(2,3,0,1);
			makeBorderDesign4(0,1,9,10);
			makeBorderDesign4(12,13,2,3);
			makeBorderDesign4(12,13,8,9);
			

			
			for (int i = 0; i < pieces.size(); i++)
			{
				int pieceX1 = pieces.get(i).getXcord();
				int pieceY1 = pieces.get(i).getYcord();
				
				if(pieceX1 == 13 && pieceY1 == 5) 
				{
					pieces.get(i).setComplexBorder(1,BORDER,BORDER,1);
					targetPieces.add(pieces.get(i));
				}
				else if(pieceX1 == 12 && pieceY1 == 5) {pieces.get(i).setComplexBorder(1,1,1,BORDER);}
				
				else if(pieceX1 == 3 && pieceY1 == 6) {
					targetPieces.add(pieces.get(i));
					pieces.get(i).setComplexBorder(1,BORDER,BORDER,1);
					}
				else if(pieceX1 == 3 && pieceY1 == 7) {pieces.get(i).setComplexBorder(BORDER,1,1,1);}
				
				else if(pieceX1 == 13 && pieceY1 == 11) {
					targetPieces.add(pieces.get(i));
					pieces.get(i).setComplexBorder(1,BORDER,BORDER,1);
					}
				else if(pieceX1 == 13 && pieceY1 == 12) {pieces.get(i).setComplexBorder(BORDER,1,1,1);}
				
				else if(pieceX1 == 3 && pieceY1 == 12) {
					targetPieces.add(pieces.get(i));
					pieces.get(i).setComplexBorder(1,1,BORDER,BORDER);
					}
				else if(pieceX1 == 4 && pieceY1 == 12) {pieces.get(i).setComplexBorder(1,BORDER,1,1);}
				
				//complex board 
				if((pieceX1 == 4 && pieceY1 == 1)||(pieceX1 == 6  && pieceY1 == 12)) {pieces.get(i).makeComplexWall("green");}
				else if((pieceX1 == 5 && pieceY1 == 7)||(pieceX1 == 9  && pieceY1 == 11)) {pieces.get(i).makeComplexWall("yellow");}
				else if((pieceX1 == 1 && pieceY1 == 13)||(pieceX1 == 11  && pieceY1 == 7)) {pieces.get(i).makeComplexWall("red");}
				else if((pieceX1 == 14 && pieceY1 == 2)||(pieceX1 == 11  && pieceY1 == 13)) {pieces.get(i).makeComplexWall("blue");}
			}
		}
		
		

		
		String[] colourRobots = {"red", "orange", "blue", "green"};
		int counter = 0;
		for(int i = 0; i < targetPieces.size(); i++)
		{
			if(i<4) {targetPieces.get(i).setTarget((URL+"Images/targetChipBlocks/star"+counter+".png"),colourRobots[counter],("star"+counter));}
			else if(i > 3 && i < 8) {targetPieces.get(i).setTarget((URL+"Images/targetChipBlocks/hex"+counter+".png"),colourRobots[counter],("hex"+counter));}
			else if(i > 7 && i < 12) {targetPieces.get(i).setTarget((URL+"Images/targetChipBlocks/diamond"+counter+".png"),colourRobots[counter],("diamond"+counter));}
			else{targetPieces.get(i).setTarget((URL+"Images/targetChipBlocks/triangle"+counter+".png"),colourRobots[counter],("triangle"+counter));}
			counter = (counter+1)%4;
		}

	}

	
	private void makeTopBottomSidesWall(int x1, int y1, String set)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if (set == "TopBottom")
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 & x == (x1+1)) {pieces.get(count).setBorder(1,BORDER,1,1);}
			}
			else
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == (y1+1) & x == (x1)) {pieces.get(count).setBorder(BORDER,1,1,1);}	
			}
		}	
	}
	
	private void makeBorderDesign1(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x2 && y == y1) {targetPieces.add(pieces.get(count));}
			if ((y == y1 & (x == x1 || x == x2)) || (y == y2  && x == x2))
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 & x == x2) {pieces.get(count).setBorder(1,BORDER,BORDER,1);}
				else {pieces.get(count).setBorder(BORDER,1,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign2(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x1 && y == y1) {targetPieces.add(pieces.get(count));}
			if ((y == y1 & (x == x1 || x == x2)) || (y == y2  && x == x1))
			{
				if(y == y1 & x == x1) {pieces.get(count).setBorder(1,1,BORDER,BORDER);}
				else if(y == y1 && x == x2) {pieces.get(count).setBorder(1,BORDER,1,1);}
				else if(y == y2 && x == x1) {pieces.get(count).setBorder(BORDER,1,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign3(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x1 && y == y2) {targetPieces.add(pieces.get(count));}
			if ((y == y2 & (x == x1 || x == x2)) || (y == y1  && x == x1))
			{
				if(y == y2 & x == x1) {pieces.get(count).setBorder(BORDER,1,1,BORDER);}
				else if(y == y1 && x == x1) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == y2 && x == x2) {pieces.get(count).setBorder(1,BORDER,1,1);}
			}
			
		}
	}
	
	private void makeBorderDesign4(int y1, int y2, int x1, int x2)
	{
		for (int count = 0; count < pieces.size(); count++)
		{
			int x = pieces.get(count).getXcord();
			int y = pieces.get(count).getYcord();
			if(x == x2 && y == y2) {targetPieces.add(pieces.get(count));}
			if ((y == y2 & (x == x1 || x == x2)) || (y == y1  && x == x2))
			{
				if(y == y2 & x == x1) {pieces.get(count).setBorder(1,1,1,BORDER);}
				else if(y == y1 && x == x2) {pieces.get(count).setBorder(1,1,BORDER,1);}
				else if(y == y2 && x == x2) {pieces.get(count).setBorder(BORDER,BORDER,1,1);}
			}
			
		}
	}
}
