import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.ArrayList;

public class BoardPiece extends JButton
{
	
	private int x_cord, y_cord;
    private boolean mainButton;
    private static final Color colorBackground = new Color(227,212,201);
    private String URL, playerType, targetPiece, targetLogoPiece, complexWall;
    private boolean stop, player, select, complexType;
    private JLabel playerLabel, targetLabel, tempTargetLabel;
    private ArrayList borders;

    
    
	public BoardPiece(int x_cord,int y_cord)
	{
		this.playerType = "";
		borders = new ArrayList();
		this.targetPiece = "";
		this.targetLogoPiece = "";
		this.complexWall = "None";
		this.complexType = false;
		player = false;
		select = false;
		URL = "";
		this.x_cord = x_cord;
		this.y_cord = y_cord;
		//this.setBackground(colorBackground);
		setPieceImage();
		this.setBorder(new LineBorder(Color.BLACK, 1));
		this.setPreferredSize(new Dimension(60, 60));
	}
	
	public void setPieceImage()
	{
		this.setIcon((new ImageIcon(URL+"Images/piece.png")));
	}
	
	public void setTarget(String address, String targetPiece, String targetLogoPiece)
	{
		targetLabel = (new JLabel(new ImageIcon(address)));
		this.setLayout(new GridLayout(0,1));
		this.add(targetLabel);
		this.targetPiece = targetPiece;
		this.targetLogoPiece = targetLogoPiece;
	}
	
	public String getTargetLogoPiece()
	{
		return this.targetLogoPiece;
	}
	
	public void removeTargetPiece()
	{
		targetLabel.remove(tempTargetLabel);
		this.targetPiece = "";
		this.targetLogoPiece = "";
	}
	
	public void addTargetPiece(String address, String targetPiece, String targetLogoPiece)
	{//created to add target in center
		tempTargetLabel = (new JLabel(new ImageIcon(address)));
		targetLabel.setLayout(new GridLayout(0,1));
		targetLabel.add(tempTargetLabel);
		this.targetPiece = targetPiece;
		this.targetLogoPiece = targetLogoPiece;
	}
	
	public void saveBorder(int top, int left, int bottom, int right)
	{
		borders.add(top);borders.add(left);borders.add(bottom);borders.add(right);
		stop = true;
	}
	
	public void setImage(String address)
	{
		JLabel tempLabel = (new JLabel(new ImageIcon(address)));
		this.setLayout(new GridLayout(0,1));
		this.add(tempLabel);
	}
	
	public void removeTarget()
	{
		this.remove(targetLabel);
		this.targetPiece = "";
	}
	
	public boolean getComplexType()
	{
		return this.complexType;
	}
	
	public void setComplexBorder(int top, int left, int bottom, int right)
	{
		stop = false;
		Icon image = new ImageIcon(URL+"Images/targetChipBlocks/border.png");
		this.setBorder((BorderFactory.createMatteBorder(top, left, bottom, right, image)));
		if(borders.size() == 4) {borders.set(0,top);borders.set(1,left);borders.set(2,bottom);borders.set(3,right);}
		else {borders.add(top);borders.add(left);borders.add(bottom);borders.add(right);}
		stop = true;
		
	}
	
	public void setBorder(int top, int left, int bottom, int right)
	{
		Icon image = new ImageIcon(URL+"Images/targetChipBlocks/border.png");
		this.setBorder((BorderFactory.createMatteBorder(top, left, bottom, right, image)));
		saveBorder(top,left,bottom,right);
	}
	
	public ArrayList getBorders()
	{
		return borders;
	}
	
	public void removePlayer()
	{
		this.remove(playerLabel);
		this.playerType = "";
		this.player = false;
	}
	
	public void setPlayer(String address, String playerType)
	{
		playerLabel = (new JLabel(new ImageIcon(address)));
		this.add(playerLabel);
		this.playerType = playerType;
		this.player = true;
		
	}
	
	public void makeComplexWall(String complex)
	{
		this.complexWall = complex;
		JLabel complexLabel = (new JLabel(new ImageIcon(URL+"Images/ComplexWall/"+complex+".png")));
		this.setLayout(new GridLayout(0,1));
		this.add(complexLabel);
		this.complexType = true;
		
	}
	
	public String getComplexWall()
	{
		return this.complexWall;
	}
	
	public String getPlayerType()
	{
		return this.playerType;
	}
	
	public void setPlayerType(String playerType)
	{
		this.playerType = playerType;
	}
	
	public String getTargetPiece()
	{
		return this.targetPiece;
	}
	
	public void setTargetPiece(String targetPiece)
	{
		this.targetPiece = targetPiece;
	}
	
	public void setColour()
	{
		this.setBackground(colorBackground);
	}
	
	public int getXcord()
    {
        return x_cord;
    }
    
    public int getYcord()
    {
        return y_cord;
    }
    
    public boolean getStop()
    {
    	return stop;
    }
    
    public void setStop(boolean stop)
    {
    	this.stop = stop;
    }
    
    public boolean getPlayer()
    {
    	return this.player;
    }
    
    public void setPlayer(boolean player)
    {
    	this.player = player;
    }
    
    public void setPieceSelect(boolean select)
    {
    	this.select = select;
    }
    
    public boolean getPieceSelect() //check if it can be selected
    {
    	return this.select;
    }
    
}