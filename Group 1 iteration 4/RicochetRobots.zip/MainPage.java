import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.event.*;
import java.awt.*;

public class MainPage extends JFrame implements ActionListener
{
	private JLabel label, startLabel, visionLabel;
	private JButton newGame, loadGame, help, startGame, visionDisplay, backButton, backButton1, exitButton;
	private JComboBox <String>playerBox;JComboBox <String>difficultyBox;JComboBox <String>boardBox;JComboBox <String>colourBox;
	private JComboBox <String>fontBox; JComboBox <String>logoBox;
	private int humanPlayers, logoCheck, font, visionCheck;
	private String difficultyAI,colorBlindness,URL,boardType;
	
	public MainPage()
	{
		URL = "";
		setTitle("Ricochet Robots");
		visionCheck = 0;
		font = 14;
		logoCheck = 0;
		colorBlindness = "None";
		boardType = "Simple";
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setUndecorated(true);
		makeMainPage();

	}
	
	private void makeMainPage()
	{
		//setSize(800,800);
		label = new JLabel((new ImageIcon(URL+"Images/BackGround/logo"+colorBlindness+".png")));
		label.setLayout(new GridLayout(3,0));
		label.add(new JLabel());

		
		JLabel sideLabel = new JLabel();
		sideLabel.setLayout(new GridLayout(0,3));
		sideLabel.add(new JLabel());
		
		JLabel buttonLabel = new JLabel();
		buttonLabel.setLayout(new GridLayout(5,0,0,20));
		newGame = new JButton((new ImageIcon(URL+"Images/Buttons/start"+logoCheck+".jpg")));
		newGame.addActionListener(this);
		
		loadGame = new JButton((new ImageIcon(URL+"Images/Buttons/load"+logoCheck+".jpg")));
		help = new JButton((new ImageIcon(URL+"Images/Buttons/help"+logoCheck+".jpg")));
		help.addActionListener(e -> helpMessage());
		
		visionDisplay = new JButton((new ImageIcon(URL+"Images/Buttons/vision"+logoCheck+".jpg")));
		visionDisplay.addActionListener(this);
		
		buttonLabel.add(newGame);
		buttonLabel.add(loadGame);
		buttonLabel.add(visionDisplay);
		buttonLabel.add(help);	
		
		exitButton = new JButton((new ImageIcon(URL+"Images/Buttons/exit"+logoCheck+".jpg")));
		exitButton.addActionListener(this);
		buttonLabel.add(exitButton);
		
		sideLabel.add(buttonLabel);
		label.add(sideLabel);
		this.add(label);
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        setResizable(false);
		setVisible(true);
		if(visionCheck == 1) {visionMessage();}
		visionCheck = 0;
	}
	
	private void startGame()
	{
		humanPlayers = 1;
		difficultyAI = "Easy";
		
		startLabel = new JLabel((new ImageIcon(URL+"Images/BackGround/logo"+colorBlindness+".png")));
		startLabel.setLayout(new GridLayout(11,0));
		for(int i = 0; i < 3; i++){startLabel.add(new JLabel());}
	
		String[] playerText = {"1","2","3","4"};
		setComboBox(playerText,"Number of Human Players Playing?","player",startLabel);
	
		for(int i = 0; i < 1; i++){startLabel.add(new JLabel());}
		String[] difficultText = {"Easy","Hard"};
		setComboBox(difficultText,"Select the Difficulty Level of Computer","difficulty",startLabel);
		
		for(int i = 0; i < 1; i++){startLabel.add(new JLabel());}
		String[] boardText = {"Simple","Complex"};
		setComboBox(boardText,"Select the Design of Board","board",startLabel);
		
		
		for(int i = 0; i < 1; i++){startLabel.add(new JLabel());}
		startGame = new JButton(((new ImageIcon(URL+"Images/Buttons/gamestart"+logoCheck+".jpg"))));
		startGame.addActionListener(this);
		backButton1 = new JButton(((new ImageIcon(URL+"Images/Buttons/back"+logoCheck+".jpg"))));
		backButton1.addActionListener(this);
		
		JLabel spaceLabel1 = new JLabel();
		spaceLabel1.setLayout(new GridLayout(2,0,0,10));
		spaceLabel1.add(startGame);
		spaceLabel1.add(backButton1);
		JLabel partLabel = new JLabel();
		partLabel.setLayout(new GridLayout(0,3));
		partLabel.add(new JLabel());
		partLabel.add(spaceLabel1);
		startLabel.add(partLabel);
		//startLabel.add(new JLabel());
		this.add(startLabel);
	}

	
	private void setComboBox(String[] arrayText, String Text, String Box, JLabel labelx)
	{
		JLabel partLabel = new JLabel();
		partLabel.setLayout(new GridLayout(0,3));
		partLabel.add(new JLabel());
		
		JLabel label = new JLabel();
		label.setLayout(new GridLayout(2,0,0,10));
		JLabel text = new JLabel(Text);
		text.setFont(new Font("Helvetica", Font.PLAIN, font));
		text.setForeground(Color.WHITE);
		label.add(text);
		
		if(Box == "difficulty")
		{
			difficultyBox = new JComboBox<>(arrayText);
			difficultyBox.setSelectedIndex(0);
			difficultyBox.addActionListener(this);
			label.add(difficultyBox);
		}
		else if(Box == "player")
		{
			playerBox = new JComboBox<>(arrayText);
			playerBox.setSelectedIndex(0);
			playerBox.addActionListener(this);
			label.add(playerBox);
		}
		else if(Box == "logo")
		{
			logoBox = new JComboBox<>(arrayText);
			logoBox.setSelectedIndex(logoCheck);
			logoBox.addActionListener(this);
			label.add(logoBox);
		}
		else if(Box == "board")
		{
			boardBox = new JComboBox<>(arrayText);
			boardBox.setSelectedIndex(0);
			boardBox.addActionListener(this);
			label.add(boardBox);
		}
		else if(Box == "graphics")
		{
			int position = 0;
			for(int i = 0; i < 4; i++) {if(arrayText[i].equals(colorBlindness)) {position = i;}}
			colourBox = new JComboBox<>(arrayText);
			colourBox.setSelectedIndex(position);
			colourBox.addActionListener(this);
			label.add(colourBox);
		}
		else if(Box == "font")
		{
			fontBox = new JComboBox<>(arrayText);
			if(font == 14) {fontBox.setSelectedIndex(0);}
			else{fontBox.setSelectedIndex(1);}
			fontBox.addActionListener(this);
			label.add(fontBox);
		}
		partLabel.add(label);
		labelx.add(partLabel);
	}
	
	private void visionMessage()
	{
		JFrame messageFrame = new JFrame();
		messageFrame.setTitle("Vision Message");
		JLabel messagePane = new JLabel((new ImageIcon(URL+"Images/message.png")));
		messageFrame.add(messagePane);
		messageFrame.setSize(922,99);
		messageFrame.setVisible(true);
		
	}
	
	private void helpMessage()
	{
		
		JFrame messageFrame = new JFrame();
		messageFrame.setTitle("Help");
		JLabel messagePane = new JLabel("Watch this video: https://www.youtube.com/watch?v=OQOMmftaWAQ");
		messageFrame.add(messagePane);
		messageFrame.setSize(922,99);
		messageFrame.setVisible(true);
		
	}
	
	private void visionDisplay()
	{
		visionLabel = new JLabel((new ImageIcon(URL+"Images/BackGround/logo"+colorBlindness+".png")));
		visionLabel.setLayout(new GridLayout(15,0));
		for(int i = 0; i < 4; i++){visionLabel.add(new JLabel());}
		
		String[] GraphicText = {"None","Protanopia","Deuteranopes","Tritanopia"};
		setComboBox(GraphicText,"Please select the color blind mode","graphics",visionLabel);
		
		for(int i = 0; i < 1; i++){visionLabel.add(new JLabel());}
		String[] FontText = {"Normal","Large"};
		setComboBox(FontText,"What size of font do you prefer?","font",visionLabel);
	
		
		for(int i = 0; i < 1; i++){visionLabel.add(new JLabel());}
		String[] logoText = {"No","Yes"};
		setComboBox(logoText,"Set logo on buttons?","logo",visionLabel);
		this.add(visionLabel);
		
		for(int i = 0; i < 1; i++){visionLabel.add(new JLabel());}
		backButton = new JButton((new ImageIcon(URL+"Images/Buttons/back"+logoCheck+".jpg")));
		backButton.addActionListener(this);
		
		JLabel partLabel = new JLabel();
		partLabel.setLayout(new GridLayout(0,3));
		
		partLabel.add(new JLabel());
		partLabel.add(backButton);

		visionLabel.add(partLabel);
		for(int i = 0; i < 4; i++){visionLabel.add(new JLabel());}
		this.add(visionLabel);
	}
	
	public void actionPerformed (ActionEvent event)
	{
		Object click = event.getSource();
        if (click instanceof JButton)
        {
        	if ((JButton)click == newGame)
            {
            	label.setVisible(false);
            	startGame();
            }
        	
        	if ((JButton)click == startGame)
            {
            	startLabel.setVisible(false);
            	new Game(humanPlayers,difficultyAI,boardType);
            	this.setVisible(false);
            }
        	
        	if ((JButton)click == visionDisplay)
            {
        		label.setVisible(false);
            	visionDisplay();
            }
        	if((JButton) click == exitButton)
        	{
        	    setVisible(false);
        	    dispose();
        	    System.exit(0);
        	}
        	if ((JButton)click == backButton || (JButton)click == backButton1)
            {
        		if((JButton)click == backButton) {visionLabel.setVisible(false);}
        		else {startLabel.setVisible(false);}
            	makeMainPage();
            }
        }
        else if(click instanceof JComboBox)
        {
        	if ((JComboBox)click == playerBox)
            {
        		String selectedPlayer = (String) playerBox.getSelectedItem();
            	if(selectedPlayer.equals("4")){difficultyBox.setEnabled(false);} 
            	else{difficultyBox.setEnabled(true);}
            	humanPlayers = Integer.parseInt(selectedPlayer);
            }
        	else if ((JComboBox)click == difficultyBox)
            {
        		String selectedDifficulty = (String) difficultyBox.getSelectedItem();
            	if(selectedDifficulty.equals("Easy")){difficultyAI = "Easy";} 
            	else{difficultyAI = "Hard";}
            }
        	else if ((JComboBox)click == fontBox)
            {
        		String fontsize = (String) fontBox.getSelectedItem();
            	if(fontsize.equals("Large")){font= 18;} 
            	else{font = 14;}
            	visionCheck = 0;
            	this.setVisible(false);
            	backButton.doClick();
            	visionDisplay.doClick();
            	this.setVisible(true);
            	visionCheck = 1;
            	
            }
        	else if ((JComboBox)click == logoBox)
            {
        		String selectedLogo = (String) logoBox.getSelectedItem();
            	if(selectedLogo.equals("Yes")){logoCheck = 1;} 
            	else{logoCheck = 0;}
            	backButton.setIcon(((new ImageIcon(URL+"Images/Buttons/back"+logoCheck+".jpg"))));
            	visionCheck = 1;
            }
        	else if ((JComboBox)click == boardBox)
            {
        		String selectedBoardType = (String) boardBox.getSelectedItem();
            	if(selectedBoardType.equals("Simple")){boardType = "Simple";} 
            	else{boardType = "Complex";}
            }
        	else if ((JComboBox)click == colourBox)
            {

        	String color = (String) colourBox.getSelectedItem();
            	if(color.equals("Protanopia")){colorBlindness = "Protanopia";} 
            	else if(color.equals("Deuteranopes")){colorBlindness = "Deuteranopes";} 
            	else if(color.equals("Tritanopia")){colorBlindness = "Tritanopia";} 
            	else{colorBlindness = "None";}
            	visionLabel.setIcon((new ImageIcon(URL+"Images/BackGround/logo"+colorBlindness+".png")));
            	visionCheck = 1;
            }
        }
	}

}
