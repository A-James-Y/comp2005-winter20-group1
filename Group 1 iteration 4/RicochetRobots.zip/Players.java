public class Players {
	
	private String name, playerType, playerTurn;
	private int bid, score;

	public Players(String name, String type)
	{
		this.playerTurn = "ready";
		this.name = name;
		this.playerType = type;
		this.bid = 0;
		this.score = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public String getPlayerTurn()
	{
		return playerTurn;
	}
	
	public void setPlayerTurn(String turn)
	{
		this.playerTurn = turn;
	}
	
}

